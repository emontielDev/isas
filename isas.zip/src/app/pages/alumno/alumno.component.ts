import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { WebcamImage } from 'ngx-webcam';
import { Subject, Observable } from 'rxjs';

@Component({
  selector: 'app-alumno',
  templateUrl: './alumno.component.html',
  styleUrls: ['./alumno.component.css']
})
export class AlumnoComponent implements OnInit {
  frmDatosPersonales: FormGroup;
  // trigger: Subject<void> = new Subject<void>();
  submitted = false;
  // videoOptions: MediaTrackConstraints = {
  //   width: { ideal: 1024 },
  //   height: { ideal: 576 }
  // };
  // webcamImage: WebcamImage = null;

  constructor(
    private formBuilder: FormBuilder,
  ) { }

  esValido(form: FormGroup, name: string): boolean {
    const input = form.controls[name];
    return ((input.touched || input.dirty) || this.submitted) && input.invalid;
  }

  invokeEvent(place: object) {
    console.log(place);
  }

  mostrarMensajeError(form: FormGroup, name: string, type: string) {
    const input = form.controls[name];
    return ((input.touched || input.dirty) || this.submitted) && input.hasError(type);
  }

  // handleImage(webcamImage: WebcamImage): void {
  //   console.log('received webcam image', webcamImage);
  //   this.webcamImage = webcamImage;
  // }

  ngOnInit() {
    this.frmDatosPersonales = this.formBuilder.group({
      nombre: ['', [Validators.required]],
      apaterno: ['', [Validators.required]],
      amaterno: ['', [Validators.required]],
      fechanacimiento: [null, [Validators.required]],
      lugarnacimiento: [''],
      nacionalidad: ['', [Validators.required]],
      curp: ['', [Validators.required]],
      correoelectronico: ['', [Validators.required, CustomValidators.email]],
      sexo: ['', [Validators.required]],
      domicilio: this.formBuilder.group({
        calle: ['', [Validators.required]],
        numeroExterior: ['', [Validators.required]],
        numeroInterior: [''],
        codigoPostal: ['', [Validators.required]],
        colonia: ['', [Validators.required]],
        delegacion: ['', [Validators.required]],
        estado: ['', [Validators.required]],
      })
    });

    // this.frmDireccion = this.formBuilder.group({
    //   calle: ['', [Validators.required]],
    //   numero: ['', [Validators.required]],
    //   colonia: ['', [Validators.required]],
    //   codigopostal: ['', [Validators.required]],
    //   delmun: ['', [Validators.required]],
    //   estado: ['', [Validators.required]],
    // });
  }

  save(): void {
    this.submitted = true;
  }

  // public get triggerObservable(): Observable<void> {
  //   return this.trigger.asObservable();
  // }

  // triggerSnapshot(): void {
  //   this.trigger.next();
  // }
}
